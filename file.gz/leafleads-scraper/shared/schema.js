module.exports = {
  csvColumns: ['Name', 'Phone', 'Email']
};
